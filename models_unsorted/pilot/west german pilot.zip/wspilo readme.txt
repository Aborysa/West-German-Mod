- wspilo00 is the source texture you sent me.
- wspilo00_16bit.map is your texture processed by MakeMAP with the -565 (16-bit) command.
- wspilo00_32bit.map is your texture processed by MakeMAP with the -888 (32-bit) command.
- wspilo00_indexed.map is your texture indexed on objects.act and processed by MAP Viewer
(old fashioned way, compatible with 1.4).